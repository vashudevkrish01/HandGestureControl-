# ✋ Hand Gesture Control (Android, Kotlin)

Control Reels / Shorts / web pages / any app using hand gestures in front of the front camera.

**Stack:** CameraX + MediaPipe Hand Landmarker + AccessibilityService (`dispatchGesture`).

| Gesture | Action |
|---|---|
| Swipe hand up | Next reel/short (swipe up) |
| Swipe hand down | Previous (swipe down) |
| Open palm (hold) | Play/Pause (tap center) |
| Two fingers (hold) | Like (double tap) |
| Fist (hold) | Back |

## Setup
1. Download the model and put it in `app/src/main/assets/hand_landmarker.task`:
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
2. Open the folder in Android Studio, let Gradle sync, run on a real phone.
3. In the app: allow camera -> enable Accessibility service -> Start gestures.
4. Open Instagram/YouTube and try the gestures.

## Notes
- Keep your hand upright, ~30-50 cm from the front camera, with good light.
- Tune thresholds in `HandGestureEngine.kt` (`SWIPE_DISTANCE`, `HOLD_FRAMES`, `COOLDOWN_MS`).
- Camera in the background works through a foreground service (notification shown).
