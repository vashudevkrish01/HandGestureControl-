package com.example.handgesture

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Performs the actual swipes/taps on whatever app is open (Reels, Shorts, browser...). */
class GestureAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun perform(gesture: Gesture) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        when (gesture) {
            Gesture.NEXT -> swipe(w / 2, h * 0.75f, w / 2, h * 0.25f)       // finger moves up
            Gesture.PREVIOUS -> swipe(w / 2, h * 0.25f, w / 2, h * 0.75f)   // finger moves down
            Gesture.PLAY_PAUSE -> tap(w / 2, h / 2, doubleTap = false)
            Gesture.LIKE -> tap(w / 2, h / 2, doubleTap = true)
            Gesture.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 250)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun tap(x: Float, y: Float, doubleTap: Boolean) {
        val path = Path().apply { moveTo(x, y) }
        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
        if (doubleTap) builder.addStroke(GestureDescription.StrokeDescription(path, 120, 50))
        dispatchGesture(builder.build(), null, null)
    }

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
    }
}
