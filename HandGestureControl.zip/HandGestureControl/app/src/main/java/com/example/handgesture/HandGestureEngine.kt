package com.example.handgesture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.abs

enum class Gesture { NEXT, PREVIOUS, PLAY_PAUSE, LIKE, BACK }

/**
 * Detects hand landmarks with MediaPipe and turns them into [Gesture]s.
 *  - Swipe hand up    -> NEXT
 *  - Swipe hand down  -> PREVIOUS
 *  - Open palm (hold) -> PLAY_PAUSE
 *  - Two fingers (hold) -> LIKE
 *  - Fist (hold)      -> BACK
 */
class HandGestureEngine(
    context: Context,
    private val onGesture: (Gesture) -> Unit
) {
    private val landmarker: HandLandmarker

    private val history = ArrayDeque<Pair<Long, Float>>() // (time, wrist y)
    private var lastFire = 0L
    private var pose: Gesture? = null
    private var poseFrames = 0

    init {
        val base = BaseOptions.builder().setModelAssetPath(MODEL).build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> handle(result) }
            .build()
        landmarker = HandLandmarker.createFromOptions(context, options)
    }

    fun analyze(proxy: ImageProxy) {
        try {
            val bmp = proxy.toBitmap()
            val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            landmarker.detectAsync(BitmapImageBuilder(rotated).build(), SystemClock.uptimeMillis())
        } finally {
            proxy.close()
        }
    }

    fun close() = landmarker.close()

    private fun handle(result: HandLandmarkerResult) {
        val now = SystemClock.uptimeMillis()
        val hands = result.landmarks()
        if (hands.isEmpty()) {
            history.clear(); pose = null; poseFrames = 0
            return
        }
        val lm = hands[0]

        history.addLast(now to lm[0].y())
        while (history.isNotEmpty() && now - history.first().first > SWIPE_WINDOW_MS) history.removeFirst()

        if (now - lastFire < COOLDOWN_MS) return

        // 1) Swipe (wrist moves fast up/down)
        if (history.size >= 4) {
            val dy = history.last().second - history.first().second
            if (abs(dy) > SWIPE_DISTANCE) {
                fire(if (dy < 0) Gesture.NEXT else Gesture.PREVIOUS, now)
                return
            }
        }

        // 2) Static pose, must be held for a few frames
        val current = classifyPose(lm)
        if (current != null && current == pose) poseFrames++ else { pose = current; poseFrames = 1 }
        if (current != null && poseFrames >= HOLD_FRAMES) fire(current, now)
    }

    private fun fire(g: Gesture, now: Long) {
        lastFire = now
        history.clear(); pose = null; poseFrames = 0
        onGesture(g)
    }

    // Assumes hand is held roughly upright (fingers pointing up).
    private fun classifyPose(lm: List<NormalizedLandmark>): Gesture? {
        val index = lm[8].y() < lm[6].y()
        val middle = lm[12].y() < lm[10].y()
        val ring = lm[16].y() < lm[14].y()
        val pinky = lm[20].y() < lm[18].y()
        val thumb = abs(lm[4].x() - lm[17].x()) > abs(lm[3].x() - lm[17].x())
        val count = listOf(index, middle, ring, pinky).count { it }
        return when {
            count == 4 && thumb -> Gesture.PLAY_PAUSE
            count == 0 && !thumb -> Gesture.BACK
            index && middle && !ring && !pinky -> Gesture.LIKE
            else -> null
        }
    }

    companion object {
        const val MODEL = "hand_landmarker.task"
        private const val SWIPE_WINDOW_MS = 350L
        private const val SWIPE_DISTANCE = 0.28f
        private const val COOLDOWN_MS = 1000L
        private const val HOLD_FRAMES = 8
    }
}
