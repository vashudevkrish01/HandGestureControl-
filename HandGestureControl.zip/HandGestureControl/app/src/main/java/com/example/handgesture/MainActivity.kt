package com.example.handgesture

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        root.addView(TextView(this).apply { text = "✋ Hand Gesture Control"; textSize = 24f })
        root.addView(status)
        root.addView(button("1. Allow camera") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            permissionLauncher.launch(perms.toTypedArray())
        })
        root.addView(button("2. Enable Accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find 'Hand Gesture Control' and turn it on", Toast.LENGTH_LONG).show()
        })
        root.addView(button("3. Start gestures") {
            ContextCompat.startForegroundService(this, Intent(this, GestureService::class.java))
            updateStatus()
        })
        root.addView(button("Stop") {
            stopService(Intent(this, GestureService::class.java))
            updateStatus()
        })
        root.addView(TextView(this).apply {
            text = "\nGestures:\n" +
                "Swipe hand up → next reel\n" +
                "Swipe hand down → previous\n" +
                "Open palm (hold) → play/pause\n" +
                "Two fingers (hold) → like\n" +
                "Fist (hold) → back"
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun updateStatus() {
        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        val a11y = GestureAccessibilityService.instance != null
        status.text = "Camera: ${if (cam) "✅" else "❌"}   Accessibility: ${if (a11y) "✅" else "❌"}   " +
            "Running: ${if (GestureService.running) "✅" else "❌"}"
    }
}
